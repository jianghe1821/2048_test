using UnityEngine;

[CreateAssetMenu(menuName = "Tile State")]
public class TileState : ScriptableObject
{
    [Header("Basic Settings")]
    public int number;                 // 数字（如2048中的数值）
    public Color backgroundColor;      // 背景颜色
    public Color textColor;            // 文字颜色

    [Header("Image Display")]
    public bool useSprite = false;     // 是否使用图片替代数字
    public Sprite sprite;              // 要展示的图片（需拖拽赋值）
    
    [Tooltip("当使用图片时，是否隐藏数字")]
    public bool hideNumberIfUsingSprite = true; // 图片模式下隐藏数字
}
