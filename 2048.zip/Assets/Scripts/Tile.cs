using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Tile : MonoBehaviour
{
    // UI组件引用
    [Header("UI Components")]
    [SerializeField] private Image backgroundImage; // 背景图片组件
    [SerializeField] private TextMeshProUGUI numberText; // 使用TextMeshPro保持一致性
    [SerializeField] private Image iconImage;       // 图标图片组件

    private TileState currentState;

    public TileState state { get { return currentState; } }//加的

    public TileCell cell { get; private set; }
    public bool locked { get; set; }

    private void Awake()
    {
        // 确保组件初始化
        if (!backgroundImage) backgroundImage = GetComponent<Image>();
        if (!numberText) numberText = GetComponentInChildren<TextMeshProUGUI>();
        
        // 初始隐藏图标
        iconImage.gameObject.SetActive(false);
    }

    // 统一状态设置方法
    public void SetState(TileState state)
    {
        if (state == null)
        {
            Debug.LogError("TileState is null!");
            return;
        }

        currentState = state;

        // 设置背景颜色
        backgroundImage.color = state.backgroundColor;

        if (state.useSprite && state.sprite != null)
        {
            // 显示图标
            iconImage.sprite = state.sprite;
            iconImage.gameObject.SetActive(true);

            // 处理数字显示
            numberText.gameObject.SetActive(!state.hideNumberIfUsingSprite);
            numberText.text = state.number.ToString();
            numberText.color = state.textColor;
        }
        else
        {
            // 仅显示数字
            iconImage.gameObject.SetActive(false);
            numberText.gameObject.SetActive(true);
            numberText.text = state.number.ToString();
            numberText.color = state.textColor;
        }

        // 调试日志
        Debug.Log($"State applied: Number={state.number}, " +
                 $"UseSprite={state.useSprite}, " +
                 $"Sprite={state.sprite != null}");
    }

    public void Spawn(TileCell cell)
    {
        if (this.cell != null) {
            this.cell.tile = null;
        }

        this.cell = cell;
        this.cell.tile = this;

        transform.position = cell.transform.position;
    }

    public void MoveTo(TileCell cell)
    {
        if (this.cell != null) {
            this.cell.tile = null;
        }

        this.cell = cell;
        this.cell.tile = this;

        StartCoroutine(Animate(cell.transform.position, false));
    }

    public void Merge(TileCell cell)
    {
        if (this.cell != null) {
            this.cell.tile = null;
        }

        this.cell = null;
        cell.tile.locked = true;

        StartCoroutine(Animate(cell.transform.position, true));
    }

    private IEnumerator Animate(Vector3 to, bool merging)
    {
        float elapsed = 0f;
        float duration = 0.1f;

        Vector3 from = transform.position;

        while (elapsed < duration)
        {
            transform.position = Vector3.Lerp(from, to, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }

        transform.position = to;

        if (merging) {
            Destroy(gameObject);
        }
    }


}

